﻿using Xamarin.Forms;

namespace XamarinNativeFacebook
{
    public class FacebookLoginButton : Button
    {
    }
}
